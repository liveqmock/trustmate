 <?

/**
*
* RefundBean modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
**/

class RefundBean
{
	var $msg;
	var $voidType;			//VOID TYPE : 1: root Transaction Id , 2: Merchant Order Number & Amount & ApprovalDay & Root Pay No 
	var $approvalDay;		//VOID TYPE 2 : YYYYMMMDD
	var $rApprovalNo;		//VOID TYPE 2 : Previous Approval Number 
	var $rPayNo;			//VOID TYPE 2 : Previous Payment Number
	var $rTransactionId;	//VOID TYPE 1 : root Transaction Id
	var $cardNumber;		//
	var $cardExpire;		//
	var $amount;			//VOID TYPE 2 : root Transaction amount
	var $curType;			//Not Necessary
	var $approvalNo;		//VOID APPROVAL NUMBER 
	var $extra;
	
  /* Constractor */
  function RefundBean(){
	
  }
  
  function toString() { 
		return         
	   str_pad($this->voidType			, 1, " ", STR_PAD_RIGHT)
	 . str_pad($this->approvalDay		, 8, " ", STR_PAD_RIGHT)
	 . str_pad($this->rApprovalNo		, 8, " ", STR_PAD_RIGHT) 
	 . str_pad($this->rPayNo			,50, " ", STR_PAD_RIGHT) 
	 . str_pad($this->rTransactionId	,12, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardNumber		,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardExpire		, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->amount			,10, "0", STR_PAD_LEFT)
	 . str_pad($this->curType			, 3, " ", STR_PAD_RIGHT)
	 . str_pad($this->approvalNo		, 8, " ", STR_PAD_RIGHT)
	 . str_pad($this->extra				,76, " ", STR_PAD_RIGHT);
  } 	
  
  function setString($msg) { 
     $this->msg = $msg;
	
	 $this->setVoidType(trim($this->nextdata(1)));	
	 $this->setApprovalDay(trim($this->nextdata(8)));	
	 $this->setRApprovalNo(trim($this->nextdata(8)));	
	 $this->setRPayNo(trim($this->nextdata(50)));	
	 $this->setRTransactionId(trim($this->nextdata(12)));	
	 $this->setCardNumber(trim($this->nextdata(20)));	
	 $this->setCardExpire(trim($this->nextdata(4)));	
	 $this->setAmount(trim($this->nextdata(10)));	
	 $this->setCurType(trim($this->nextdata(3)));	
	 $this->setApprovalNo(trim($this->nextdata(8)));	 
	 $this->setExtra(trim($this->nextdata(76)));	

  } 	  

	
	function nextdata($size) {
		$data = substr($this->msg,0,$size);
		$this->msg = substr($this->msg,$size);
		return $data;
	}

	function getMsg() {
		return $this->msg;
	}
	function setMsg($msg) {
		$this->msg = $msg;
	}
	function getVoidType() {
		return $this->voidType;
	}
	function setVoidType($voidType) {
		$this->voidType = $voidType;
	}
	function getApprovalDay() {
		return $this->approvalDay;
	}
	function setApprovalDay($approvalDay) {
		$this->approvalDay = $approvalDay;
	}
	function getRApprovalNo() {
		return $this->rApprovalNo;
	}
	function setRApprovalNo($approvalNo) {
		$this->rApprovalNo = $approvalNo;
	}
	function getRPayNo() {
		return $this->rPayNo;
	}
	function setRPayNo($payNo) {
		$this->rPayNo = $payNo;
	}
	function getRTransactionId() {
		return $this->rTransactionId;
	}
	function setRTransactionId($transactionId) {
		$this->rTransactionId = $transactionId;
	}
	function getCardNumber() {
		return $this->cardNumber;
	}
	function setCardNumber($cardNumber) {
		$this->cardNumber = $cardNumber;
	}
	function getCardExpire() {
		return $this->cardExpire;
	}
	function setCardExpire($cardExpire) {
		$this->cardExpire = $cardExpire;
	}
	function getAmount() {
		return $this->amount;
	}
	function setAmount($amount) {
		$this->amount = $amount;
	}
	function getCurType() {
		return $this->curType;
	}
	function setCurType($curType) {
		$this->curType = $curType;
	}
	function getApprovalNo() {
		return $this->approvalNo;
	}
	function setApprovalNo($approvalNo) {
		$this->approvalNo = $approvalNo;
	}
	function getExtra() {
		return $this->extra;
	}
	function setExtra($extra) {
		$this->extra = $extra;
	}
		
}	

 ?>
 
