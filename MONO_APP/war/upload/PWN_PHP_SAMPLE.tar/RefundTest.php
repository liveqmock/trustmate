<?php

/**
*
* Refund modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
*
* Please edit this configuration PWN_GATEWAY/conf/service.xml 
* Need to modify the information below to service.xml is normally available for testing.
* PANWORLD NETWORK TEST SERVER = test.panworld-net.com(211.115.72.192) 
* PANWORLD NETWORK REAL SERVER = service.panworld-net.com(211.115.72.193)
* PANWORLD NETWORK SERVER PORT = 20000
* Please send to me your ip address (panworld@panworld-net.com)
* REFUND will be discusses. 
* 1> for the day will be processed in the CANCEL is no additional charges. 
* 2> 3 months before and 3 months after REFUND processing will need to contact a representative.
**/

require_once('SocketClient.php');
require_once('HeaderBean.php');
require_once('RefundBean.php');
require_once('class_oolog.php');

/* define PanWorld server infomation */
$Payment_Host = "localhost";	//local PWN(GSI)_GATEWAY IP
$Payment_Port = 20000;			//local PWN(GSI)_GATEWAY PORT



/* Log */
$datum=date("Y-m-d");
$l=& new oolog("./".$datum.".log", FILE | SCREEN |APPEND);
$l->log("debugging with default values", DEBUG);


/* Generate HeaderBean Packet*/
$headerBean = new HeaderBean();
$headerBean->setSpecLength("0396");				//Refund Packet Size : 0396 (FIXED)
$headerBean->setSpecType("CFIX");				//CFIX (FIXED)
$headerBean->setTrnType("T002");				//T002: Request Refund
$headerBean->setMerchantId("panworld");			//Merchant Id ( please contact manager )
$headerBean->setMallId("panworld1");			//Sub MALL ID ( your MerchantID or Sub Merchant ID)
$headerBean->setServiceType("WEB");				//Merchant Order Number		
$headerBean->setIpAddress("127.0.0.1");			//Merchant Customer Name ( please insert English )
$headerBean->setTrnDate(date("YmdHis"));		//Merchant Customer EMail Address
$headerBean->setTrnResDate("");					//Merchant Customer PhoneNumber		
$headerBean->setPayNo(date("YmdHis"));			//Merchant Order Number or Reference Number or TrackingOrderNumber
$headerBean->setTransactionId("");				//TransactionId by PanWorldNetwork
$headerBean->setResultCd("");					//Transaction Result Cd 0:Success, 1: Failure, 2: Error
$headerBean->setResultMsg("");					//Transaction Result Code 
$headerBean->setExtra("");						//User Information (echo field)

/* Generate RefundBean Packet*/
$refundBean = new RefundBean();
$refundBean->setVoidType("1");					//REFUND TYPE = 1
$refundBean->setRTransactionId("");				//Successful, the transaction number for transactions
echo "<br/>req ==> [".$headerBean->toString().$refundBean->toString()."]";
$l->log("req ==> [".$headerBean->toString().$refundBean->toString()."]", FILE, false, __LINE__);


/* Connect and receive data */

$socketClient = new SocketClient();
$socketClient->debug = TRUE;
if (!$socketClient->pwn_connect($Payment_Host,$Payment_Port)){
	$l->log("Cannot connect destination", FILE, false, __LINE__);
	die("Cannot connect\n");
}
$data = $socketClient->pwn_send($headerBean->toString().$refundBean->toString(), 400); 
$l->log("res ==> [".$data."]" , FILE, false, __LINE__);
echo "<br/>res ==> [".$data."]";
$socketClient->quit();

$headerBean->setString($data);
$refundBean->setString(substr($data,200));

if($headerBean->getResultCd() == '0'){
	$l->log("Refund Success", FILE, false, __LINE__);
	echo "<br/>Refund Success";
}else{
	$l->log("Refund Failure ResultMsg=".$headerBean->getResultMsg(), FILE, false, __LINE__);
	echo "<br/>Refund Failure ResultMsg=".$headerBean->getResultMsg();
}


$l->log("=========== HEADER BEAN =========== ", FILE, false, __LINE__);
$l->log("specLength =".$headerBean->getSpecLength(), FILE, false, __LINE__);
$l->log("specType =".$headerBean->getSpecType(), FILE, false, __LINE__);
$l->log("trnType =".$headerBean->getTrnType(), FILE, false, __LINE__);
$l->log("merchantId =".$headerBean->getMerchantId(), FILE, false, __LINE__);
$l->log("mallId =".$headerBean->getMallId(), FILE, false, __LINE__);
$l->log("serviceType =".$headerBean->getServiceType(), FILE, false, __LINE__);
$l->log("ipAddress =".$headerBean->getIpAddress(), FILE, false, __LINE__);
$l->log("trnDate =".$headerBean->getTrnDate(), FILE, false, __LINE__);
$l->log("trnResDate =".$headerBean->getTrnResDate(), FILE, false, __LINE__);
$l->log("payNo =".$headerBean->getPayNo(), FILE, false, __LINE__);
$l->log("TransactionId =".$headerBean->getTransactionId(), FILE, false, __LINE__);
$l->log("resultCd =".$headerBean->getResultCd(), FILE, false, __LINE__);
$l->log("resultMsg =".$headerBean->getResultMsg(), FILE, false, __LINE__);
$l->log("extra =".$headerBean->getExtra(), FILE, false, __LINE__);
$l->log("=========== REFUND BEAN =========== ", FILE, false, __LINE__);
$l->log("voidType =".$refundBean->getVoidType(), FILE, false, __LINE__);
$l->log("approvalDay =".$refundBean->getApprovalDay(), FILE, false, __LINE__);
$l->log("rApprovalNo =".$refundBean->getRApprovalNo(), FILE, false, __LINE__);
$l->log("rPayNo =".$refundBean->getRPayNo(), FILE, false, __LINE__);
$l->log("rTransactionId =".$refundBean->getRTransactionId(), FILE, false, __LINE__);
$l->log("amount =".$refundBean->getAmount(), FILE, false, __LINE__);
$l->log("curType =".$refundBean->getCurType(), FILE, false, __LINE__);
$l->log("approvalNo =".$refundBean->getApprovalNo(), FILE, false, __LINE__);
$l->log("extra =".$refundBean->getExtra(), FILE, false, __LINE__);


echo "<br/>=========== HEADER BEAN =========== ";
echo "<br/>specLength =".$headerBean->getSpecLength();
echo "<br/>specType =".$headerBean->getSpecType();
echo "<br/>trnType =".$headerBean->getTrnType();
echo "<br/>merchantId =".$headerBean->getMerchantId();
echo "<br/>mallId =".$headerBean->getMallId();
echo "<br/>serviceType =".$headerBean->getServiceType();
echo "<br/>ipAddress =".$headerBean->getIpAddress();
echo "<br/>trnDate =".$headerBean->getTrnDate();
echo "<br/>trnResDate =".$headerBean->getTrnResDate();
echo "<br/>payNo =".$headerBean->getPayNo();
echo "<br/>TransactionId =".$headerBean->getTransactionId();
echo "<br/>resultCd =".$headerBean->getResultCd();
echo "<br/>resultMsg =".$headerBean->getResultMsg();
echo "<br/>extra =".$headerBean->getExtra();
echo "<br/>=========== REFUND BEAN =========== ";
echo "<br/>voidType =".$refundBean->getVoidType();
echo "<br/>approvalDay =".$refundBean->getApprovalDay();
echo "<br/>rApprovalNo =".$refundBean->getRApprovalNo();
echo "<br/>rPayNo =".$refundBean->getRPayNo();
echo "<br/>rTransactionId =".$refundBean->getRTransactionId();
echo "<br/>amount =".$refundBean->getAmount();
echo "<br/>curType =".$refundBean->getCurType();
echo "<br/>approvalNo =".$refundBean->getApprovalNo();
echo "<br/>extra =".$refundBean->getExtra();


$l->closelog();

?>

 
 