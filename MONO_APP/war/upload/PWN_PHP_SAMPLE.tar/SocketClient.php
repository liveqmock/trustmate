<?

/**
*
* Payment modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
**/

class SocketClient
{
	var $debug;
	var $timeout;
	var $_resp ;

	/* Constractor */
	function SocketClient()
	{
		$this->debug = FALSE;
		$this->timeout = 60;
	}

	/* Public functions */
	function pwn_connect($server, $port)
	{
		$this->pwn_debug("Trying to ".$server.":".$port." ...\n");
		$this->pwn_sock = @fsockopen($server, $port, $errno, $errstr, $this->timeout);

		if (!$this->pwn_sock ) {
			$this->pwn_debug("Error : Cannot connect to remote host \"".$server.":".$port."\"\n");
			$this->pwn_debug("Error : fsockopen() ".$errstr." (".$errno.")\n");
			return FALSE;
		}
		$this->pwn_debug("Connected to remote host \"".$server.":".$port."\"\n");

		return TRUE;
	}

	function pwn_send($msg,$size)
	{
	  if (!$this->pwn_sock ) return FALSE;
		fputs($this->pwn_sock, $msg);
		
		do {
			$res = fgets($this->pwn_sock, 512);
			$this->_resp.= $res;
		} while (strlen($this->_resp) < $size);		
		
		return $this->_resp;
	}

	function quit()
	{
		if (!fclose($this->pwn_sock)) {
			$this->pwn_debug("Error : QUIT command failed\n");
			return FALSE;
		}
		$this->pwn_debug("Disconnected from remote host\n");
		return TRUE;
	}


	function pwn_debug($message = "")
	{
		if ($this->debug) {
			echo $message;
		}
		return TRUE;
	}
}
?>