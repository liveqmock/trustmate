 <?

/**
*
* HeaderBean modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
**/

class HeaderBean
{
	var $msg;
	var $specLength;		//SPEC LENGTH
	var $specType;			//CFIX (FIXED)
	var $trnType;			//T001:Payment , T002:Refund , T003:Search Transaction
	var $merchantId ;		//Merchant Id ( please contact manager )
	var $mallId;			//SUB MALL ID ( your MerchantID or Sub Merchant ID)
	var $serviceType;		//Access Device ( TERMINAL,MOBILE,WEB)
	var $ipAddress;			//Client IP Address
	var $trnDate;			//request date format :YYYYMMDDHHMMSS
	var $trnResDate;		//response date format : YYYYMMDDHHMMSS(
	var $payNo	;			//Merchant Order Number or Reference Number or TrackingOrderNumber
	var $transactionId;		//TransactionId by PanWorldNetwork
	var $resultCd;			//Transaction Result Cd 0:Success, 1: Failure, 2: Error
	var $resultMsg;			//Transaction Result Code 
	var $extra;
	
  /* Constractor */
  function HeaderBean(){
	
  }
  
  function toString() { 
		return 
	   str_pad($this->specLength		, 4, "0", STR_PAD_LEFT)
	 . str_pad($this->specType			, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->trnType			, 4, " ", STR_PAD_RIGHT) 
	 . str_pad($this->merchantId		,20, " ", STR_PAD_RIGHT) 
	 . str_pad($this->mallId			,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->serviceType		, 8, " ", STR_PAD_RIGHT)
	 . str_pad($this->ipAddress			,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->trnDate			,14, " ", STR_PAD_RIGHT)
	 . str_pad($this->trnResDate		,14, " ", STR_PAD_RIGHT)
	 . str_pad($this->payNo				,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->transactionId		,12, " ", STR_PAD_RIGHT)
	 . str_pad($this->resultCd			, 1, " ", STR_PAD_RIGHT)
	 . str_pad($this->resultMsg			, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->extra				,25, " ", STR_PAD_RIGHT);
  } 	
  
  function setString($msg) { 
     $this->msg = $msg;

     $this->nextdata(4);	
	 $this->setSpecType(trim($this->nextdata(4)));	
	 $this->setTrnType(trim($this->nextdata(4)));	
	 $this->setMerchantId(trim($this->nextdata(20)));	
	 $this->setMallId(trim($this->nextdata(20)));	
	 $this->setServiceType(trim($this->nextdata(8)));	
	 $this->setIpAddress(trim($this->nextdata(20)));	
	 $this->setTrnDate(trim($this->nextdata(14)));	
	 $this->setTrnResDate(trim($this->nextdata(14)));	
	 $this->setPayNo(trim($this->nextdata(50)));	
	 $this->setTransactionId(trim($this->nextdata(12)));	 
	 $this->setResultCd(trim($this->nextdata(1)));	
	 $this->setResultMsg(trim($this->nextdata(4)));		
	 $this->setExtra(trim($this->nextdata(25)));	

  } 	  

	
	function nextdata($size) {
		$data = substr($this->msg,0,$size);
		$this->msg = substr($this->msg,$size);
		return $data;
	}

	function getSpecLength() {
		return $this->specLength;
	}
	function setSpecLength($specLength) {
		$this->specLength = $specLength;
	}
	function getSpecType() {
		return $this->specType;
	}
	function setSpecType($specType) {
		$this->specType = $specType;
	}
	function getTrnType() {
		return $this->trnType;
	}
	function setTrnType($trnType) {
		$this->trnType = $trnType;
	}
	function getMerchantId() {
		return $this->merchantId;
	}
	function setMerchantId($merchantId) {
		$this->merchantId = $merchantId;
	}
	function getMallId() {
		return $this->mallId;
	}
	function setMallId($mallId) {
		$this->mallId = $mallId;
	}
	function getServiceType() {
		return $this->serviceType;
	}
	function setServiceType($serviceType) {
		$this->serviceType = $serviceType;
	}
	function getIpAddress() {
		return $this->ipAddress;
	}
	function setIpAddress($ipAddress) {
		$this->ipAddress = $ipAddress;
	}
	function getTrnDate() {
		return $this->trnDate;
	}
	function setTrnDate($trnDate) {
		$this->trnDate = $trnDate;
	}
	function getTrnResDate() {
		return $this->trnResDate;
	}
	function setTrnResDate($trnResDate) {
		$this->trnResDate = $trnResDate;
	}
	function getPayNo() {
		return $this->payNo;
	}
	function setPayNo($payNo) {
		$this->payNo = $payNo;
	}
	function getTransactionId() {
		return $this->transactionId;
	}
	function setTransactionId($transactionId) {
		$this->transactionId = $transactionId;
	}
	function getResultCd() {
		return $this->resultCd;
	}
	function setResultCd($resultCd) {
		$this->resultCd = $resultCd;
	}
	function getResultMsg() {
		return $this->resultMsg;
	}
	function setResultMsg($resultMsg) {
		$this->resultMsg = $resultMsg;
	}
	function getExtra() {
		return $this->extra;
	}
	function setExtra($extra) {
		$this->extra = $extra;
	}
	function getMsg() {
		return $this->msg;
	}
	
  
	
}	

 ?>
 
