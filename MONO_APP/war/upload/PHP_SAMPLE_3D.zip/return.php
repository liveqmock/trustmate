<?
	$proceed		= $_POST["proceed"];
	$xid			= $_POST["xid"];
	$eci			= $_POST["eci"];
	$cavv			= $_POST["cavv"];
	$cardno			= $_POST["cardno"];
	$errCode		= $_POST["errCode"];
	
?>
<html>
<body>
<script language="javascript">
<!--
		function return_proceed()
		{
			parent.paramSet("<?echo($xid)?>","<?echo($eci)?>","<?echo($cavv)?>", "<? echo($cardno)?>");

			parent.proceed('<?echo($proceed)?>','<?echo($errCode)?>');
			location.href="./blank.html";
		}
		return_proceed();
-->
</script>
</body>
</html>