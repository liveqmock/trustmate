<?php

/**
*
* Payment modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.1
*
* Please edit this configuration PWN_GATEWAY/conf/service.xml 
* Need to modify the information below to service.xml is normally available for testing.
* PANWORLD NETWORK REAL SERVER = app.monohitech.com
* PANWORLD NETWORK SERVER PORT = 20000
* Please send to me your ip address (redsky@monohitech.com)
*
**/

require_once('SocketClient.php');
require_once('HeaderBean.php');
require_once('PaymentBean.php');
require_once('class_oolog.php');


/* define PanWorld server infomation */
$Payment_Host = "localhost";	//local PWN(GSI)_GATEWAY IP
$Payment_Port = 20000;			//local PWN(GSI)_GATEWAY PORT


/* PARAMETER RECEIVE*/
$CARDNO=$_POST['CARDNO'];
$EXPIRY=$_POST['EXPIRY'];
$PAYNO = $_POST['PAYNO'];
$PAYEMAIL = $_POST['PAYEMAIL'];
$PAYNAME = $_POST['PAYNAME'];
$PAYTELNO = $_POST['PAYTELNO'];
$AMOUNT = $_POST['AMOUNT'];
$PRODUCTTYPE = $_POST['PRODUCTTYPE'];
$PRODUCTNAME = $_POST['PRODUCTNAME'];
$MERCHANT_ID = $_POST['MERCHANT_ID'];
$xid = $_POST['xid'];
$eci = $_POST['eci'];
$cavv = $_POST['cavv'];
$cavv = str_pad($cavv,40, " ", STR_PAD_RIGHT) .str_pad($xid,40, " ", STR_PAD_RIGHT) .str_pad($eci,2, " ", STR_PAD_RIGHT);
/* Log */
$datum=date("Y-m-d");
$l=& new oolog("./".$datum.".log", FILE | SCREEN |APPEND);
$l->log("debugging with default values", DEBUG);


/* Generate HeaderBean Packet*/
$headerBean = new HeaderBean();
$headerBean->setSpecLength("0746");				//PAYMENT PACKET SIZE (FIXED)
$headerBean->setSpecType("CFIX");				//CFIX (FIXED)
$headerBean->setTrnType("T001");				//T001:Payment
$headerBean->setMerchantId($MERCHANT_ID);		//Merchant Id ( please contact manager )
$headerBean->setMallId($MERCHANT_ID);			//Sub MALL ID ( your MerchantID or Sub Merchant ID)
$headerBean->setServiceType("WEB");				//Merchant Order Number		
$headerBean->setIpAddress("127.0.0.1");			//Merchant Customer Name ( please insert English )
$headerBean->setTrnDate(date("YmdHis"));		//Merchant Customer EMail Address
$headerBean->setTrnResDate("");					//Merchant Customer PhoneNumber		
$headerBean->setPayNo($PAYNO);					//Merchant Order Number or Reference Number or TrackingOrderNumber
$headerBean->setTransactionId("");				//TransactionId by PanWorldNetwork
$headerBean->setResultCd("");					//Transaction Result Cd 0:Success, 1: Failure, 2: Error
$headerBean->setResultMsg("");					//Transaction Result Code 
$headerBean->setExtra("");						//User Information (echo field)

/* Generate PaymentBean Packet*/
$paymentBean = new PaymentBean();
$paymentBean->setCardNumber($CARDNO);			//TEST CARD NUMBER 3333444455556666;
$paymentBean->setCardExpire($EXPIRY);			//Card Expire (YYMM)
$paymentBean->setCardCVV("");
$paymentBean->setCardPassword("");
$paymentBean->setPayUserId($PAYNAME);			//Payment User ID   ( English)
$paymentBean->setPayName($PAYNAME);				//Payment User Name ( English)
$paymentBean->setPayTelNo($PAYTELNO);			//Payment User Tel Number
$paymentBean->setPayEmail($PAYEMAIL);			//Payment User Email
$paymentBean->setProductType($PRODUCTTYPE);		//Payment Product Type ( 0:product,1:contents)
$paymentBean->setProductName($PRODUCTNAME);		
$paymentBean->setAmount($AMOUNT);				//10.01$ --> 1001 (USD)
$paymentBean->setCurType("USD");
/* 2013-04-30 3D-SECURE LAYER*/
$paymentBean->setDomain($_SERVER['SERVER_NAME']);	//Your Web Site Domain
$paymentBean->setCavv($cavv);					//CAVV[40]+XID[40]+ECI[2] = 80byte
$paymentBean->setExtra("");
echo "<br/>req ==> [".$headerBean->toString().$paymentBean->toString()."]";
$l->log("req ==> [".$headerBean->toString().$paymentBean->toString()."]", FILE, false, __LINE__);


/* Connect and receive data */

$socketClient = new SocketClient();
$socketClient->debug = TRUE;
if (!$socketClient->pwn_connect($Payment_Host,$Payment_Port)) {
	$l->log("Cannot connect destination", FILE, false, __LINE__);
	die("Cannot connect\n");
}
$data = $socketClient->pwn_send($headerBean->toString().$paymentBean->toString(), 600); 
$l->log("res ==> [".$data."]" , FILE, false, __LINE__);
echo "<br/>res ==> [".$data."]";
$socketClient->quit();

$headerBean->setString($data);
$paymentBean->setString(substr($data,200));


if($headerBean->getResultCd() == '0'){
	$l->log("Payment Success", FILE, false, __LINE__);
	echo "<br/>Payment Success";
}else{
	$l->log("Payment Failure ResultMsg=".$headerBean->getResultMsg(), FILE, false, __LINE__);
	echo "<br/>Payment Failure ResultMsg=".$headerBean->getResultMsg();
}


$l->log("=========== HEADER BEAN =========== ", FILE, false, __LINE__);
$l->log("specLength =".$headerBean->getSpecLength(), FILE, false, __LINE__);
$l->log("specType =".$headerBean->getSpecType(), FILE, false, __LINE__);
$l->log("trnType =".$headerBean->getTrnType(), FILE, false, __LINE__);
$l->log("merchantId =".$headerBean->getMerchantId(), FILE, false, __LINE__);
$l->log("mallId =".$headerBean->getMallId(), FILE, false, __LINE__);
$l->log("serviceType =".$headerBean->getServiceType(), FILE, false, __LINE__);
$l->log("ipAddress =".$headerBean->getIpAddress(), FILE, false, __LINE__);
$l->log("trnDate =".$headerBean->getTrnDate(), FILE, false, __LINE__);
$l->log("trnResDate =".$headerBean->getTrnResDate(), FILE, false, __LINE__);
$l->log("payNo =".$headerBean->getPayNo(), FILE, false, __LINE__);
$l->log("TransactionId =".$headerBean->getTransactionId(), FILE, false, __LINE__);
$l->log("resultCd =".$headerBean->getResultCd(), FILE, false, __LINE__);
$l->log("resultMsg =".$headerBean->getResultMsg(), FILE, false, __LINE__);
$l->log("extra =".$headerBean->getExtra(), FILE, false, __LINE__);
$l->log("=========== PAYMENT BEAN =========== ", FILE, false, __LINE__);
$l->log("payUserId =".$paymentBean->getPayUserId(), FILE, false, __LINE__);
$l->log("payName =".$paymentBean->getPayName(), FILE, false, __LINE__);
$l->log("payTelNo =".$paymentBean->getPayTelNo(), FILE, false, __LINE__);
$l->log("payEmail =".$paymentBean->getPayEmail(), FILE, false, __LINE__);
$l->log("productType =".$paymentBean->getProductType(), FILE, false, __LINE__);
$l->log("productName =".$paymentBean->getProductName(), FILE, false, __LINE__);
$l->log("amount =".$paymentBean->getAmount(), FILE, false, __LINE__);
$l->log("curType =".$paymentBean->getCurType(), FILE, false, __LINE__);
$l->log("approvalNo =".$paymentBean->getApprovalNo(), FILE, false, __LINE__);
$l->log("domain =".$paymentBean->getDomain(), FILE, false, __LINE__);
$l->log("cavv =".$paymentBean->getCavv(), FILE, false, __LINE__);
$l->log("extra =".$paymentBean->getExtra(), FILE, false, __LINE__);


echo "<br/>=========== HEADER BEAN =========== ";
echo "<br/>specLength =".$headerBean->getSpecLength();
echo "<br/>specType =".$headerBean->getSpecType();
echo "<br/>trnType =".$headerBean->getTrnType();
echo "<br/>merchantId =".$headerBean->getMerchantId();
echo "<br/>mallId =".$headerBean->getMallId();
echo "<br/>serviceType =".$headerBean->getServiceType();
echo "<br/>ipAddress =".$headerBean->getIpAddress();
echo "<br/>trnDate =".$headerBean->getTrnDate();
echo "<br/>trnResDate =".$headerBean->getTrnResDate();
echo "<br/>payNo =".$headerBean->getPayNo();
echo "<br/>TransactionId =".$headerBean->getTransactionId();
echo "<br/>resultCd =".$headerBean->getResultCd();
echo "<br/>resultMsg =".$headerBean->getResultMsg();
echo "<br/>extra =".$headerBean->getExtra();
echo "<br/>=========== PAYMENT BEAN =========== ";
echo "<br/>payUserId =".$paymentBean->getPayUserId();
echo "<br/>payName =".$paymentBean->getPayName();
echo "<br/>payTelNo =".$paymentBean->getPayTelNo();
echo "<br/>payEmail =".$paymentBean->getPayEmail();
echo "<br/>productType =".$paymentBean->getProductType();
echo "<br/>productName =".$paymentBean->getProductName();
echo "<br/>amount =".$paymentBean->getAmount();
echo "<br/>curType =".$paymentBean->getCurType();
echo "<br/>approvalNo =".$paymentBean->getApprovalNo();
echo "<br/>extra =".$paymentBean->getExtra();

$l->closelog();

?>

 
 