 <?

/**
*
* AuthBean modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
**/

class AuthBean
{
	var $msg;
	var $authType;			//AUTH TYPE : A: CardNumber & CardExpire , B: CardNumber & CardExpire & CVV , C: CardNumber & CardExpire & Password
	var $cardNumber;		//
	var $cardExpire;		// 
	var $cardCvv;			//
	var $cardPassword;		//
	var $cardFiller;		//
	var $payName;			//
	var $payTelno;			//
	var $message;			//
	
  /* Constractor */
  function AuthBean(){
	
  }
  
  function toString() { 
		return         
	   str_pad($this->authType			, 1, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardNumber		,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardExpire		, 4, " ", STR_PAD_RIGHT) 
	 . str_pad($this->cardCvv			, 4, " ", STR_PAD_RIGHT) 
	 . str_pad($this->cardPassword		, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardFiller		,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->payName			,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->payTelno			,15, " ", STR_PAD_RIGHT)
	 . str_pad($this->message			,152, " ", STR_PAD_RIGHT);
  } 	
  
  function setString($msg) { 
     $this->msg = $msg;
	
	 $this->setAuthType(trim($this->nextdata(1)));	
	 $this->setCardNumber(trim($this->nextdata(20)));	
	 $this->setCardExpire(trim($this->nextdata(4)));	
	 $this->setCardCvv(trim($this->nextdata(4)));	
	 $this->setCardPassword(trim($this->nextdata(4)));	
	 $this->setCardFiller(trim($this->nextdata(50)));	
	 $this->setPayName(trim($this->nextdata(50)));	
	 $this->setPayTelno(trim($this->nextdata(15)));
	 $this->setMessage(trim($this->nextdata(152)));

  } 	  

	
	function nextdata($size) {
		$data = substr($this->msg,0,$size);
		$this->msg = substr($this->msg,$size);
		return $data;
	}

	function getMsg() {
		return $this->msg;
	}
	function setMsg($msg) {
		$this->msg = $msg;
	}
	function getAuthType() {
		return $this->authType;
	}
	function setAuthType($authType) {
		$this->authType = $authType;
	}
	function getCardNumber() {
		return $this->cardNumber;
	}
	function setCardNumber($cardNumber) {
		$this->cardNumber = $cardNumber;
	}
	function getCardExpire() {
		return $this->cardExpire;
	}
	function setCardExpire($cardExpire) {
		$this->cardExpire = $cardExpire;
	}
	function getCardCvv() {
		return $this->cardCvv;
	}
	function setCardCvv($cardCvv) {
		$this->cardCvv = $cardCvv;
	}
	function getCardPassword() {
		return $this->cardPassword;
	}
	function setCardPassword($cardPassword) {
		$this->cardPassword = $cardPassword;
	}
	function getCardFiller() {
		return $this->cardFiller;
	}
	function setCardFiller($cardFiller) {
		$this->cardFiller = $cardFiller;
	}
	function getPayName() {
		return $this->payName;
	}
	function setPayName($payName) {
		$this->payName = $payName;
	}
	function getPayTelno() {
		return $this->payTelno;
	}
	function setPayTelno($payTelno) {
		$this->payTelno = $payTelno;
	}
	function getMessage() {
		return $this->message;
	}
	function setMessage($message) {
		$this->message = $message;
	}
		
}	

 ?>
 
