<?
	//Common Parameter
	$NEXT_URL	="./payment.php";		//PGMS SYSTEM URL 
	$V3D_URL		="https://kspay.ksnet.to/abroadMPI/veri_host.jsp";//3D URL 

	$TRN_TYPE		="T001";										//Transaction Type T001 : Credit Card Payment, T002 : Credit Card Cancelation , T003 : Inquery 
	$MERCHANT_ID	="";											//PAYMENT MERCHANT ID
	$MALL_ID		="";											//PAYMENT MALL ID (Merchant Id can be the same 
	$SERVICE_TYPE	="WEB";											//WEB , MOBILE , TERMINAL 
	$IP_ADDRESS		=$_SERVER["REMOTE_ADDR"];						//Payment User Ipaddress
	$TRN_DATE		=date("YmdHis");								//Transaction Date (YYYYMMDDHHMMSS)
	$PAY_NO			=date("YmdHis");								//Merchant Order Number
	$RES_TYPE		="TEXT";										//REDIRECT TYPE ( TEXT or REDIRECT)
	//Credit Card Approval
	$CARD_NUMBER	="";											//Credit Card Number
	$CARD_EXPIRE	="";											//Credit Card Expiration Date (YYMM)
	$PAY_USERID		="TEST USERID";									//Merchant User Id (Required)
	$PAY_NAME		="TEST USERNAME";								//Merchant User Name (Required)
	$PAY_TELNO		="821099999999";								//Merchant User Tel Number (Required)
	$PAY_EMAIL		="test@test.com";								//Merchant User Email (Required)
	$PRODUCT_TYPE	="0";											// "0" : Goods, "1":Contents (Required)
	$PRODUCT_NAME	="PRDOCUTNAME";									//Name of Product
	$CUR_TYPE		="USD";											//Currency Type (Required)
	$AMOUNT			="101";											//USD 1.01$ => 101 (Required)
	$DOMAIN			="pg.hanapayglobal.com"	;						//Merchant URL (Required)
    
?>
<html>
<head>
	<title>3D TEST</title>
	<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
		<style><!--
		a:link {  color: #444444; text-decoration: none}
		a:visited {  text-decoration: none; color:#666666; }
		a:hover {  color: #ff0000; text-decoration: underline}
		a:active {  color: #7d7d7d; text-decoration: none}
		.fontsize {  font-size: 9pt}
		.textbox {  font-size: 9pt; background-color: #E8E8E8; overflow: auto; position: static; visibility: visible; border: 1px #999999 solid}
		td { font-family: "Tahoma"; font-size: 9pt}
		input { font-family: "Tahoma"; font-size: 9pt}
		select { font-family: "Tahoma"; font-size: 9pt}
		option { font-family: "Tahoma"; font-size: 9pt}
		p { font-family: "Tahoma"; font-size: 9pt}
		font { font-family: "Tahoma";  font-size: 9pt}
		textarea { font-family: "Tahoma";  font-size: 9pt}
		body { font-family: "Tahoma";  font-size: 9pt;}
		-->
		</style>
		
		
	<script language="javascript">

	function getReturnUrl(){
		var returnUrl = location.href;
		return returnUrl.substring(0, returnUrl.lastIndexOf('/')) + '/return.php';	
	}
	/* 1. 3D SECURE Payment process */
	function submit3d(){

		var v3d = document.Visa3d;
		var frm = document.payment;

		v3d.dummy.value="blank.html";		/* remove popup*/
		v3d.pan.value = frm.CARD_NUMBER.value ;
		v3d.expiry.value = frm.CARD_EXPIRE.value;
		v3d.purchase_amount.value = frm.AMOUNT.value;
		v3d.amount.value = frm.AMOUNT.value;

		v3d.returnUrl.value = getReturnUrl();
		v3d.action = "<?echo($V3D_URL)?>";
		v3d.submit();
	}

	/* 2. Through the authorized data from v3d.action will be calling the paramSet, below function will be set like as below. */
	function paramSet(xid, eci, cavv, cardno){
		var frm = document.payment;
		
		frm.xid.value = xid;
		frm.eci.value = eci;
		frm.cavv.value = cavv;

		if (arguments.length > 3 && cardno != null && cardno.length>10){
			frm.CARD_NUMBER.value = cardno;
		}
		
	}

	/* The function for whether make payment.The calling this function is from return.php instead of authorized page.
	The authorized parameters and submit will be returned to PaymentTest.php.*/
	function proceed(arg,errCode){
	
		var frm = document.payment;
		
		var xid = frm.xid.value;
		var eci = frm.eci.value;
		var cavv = frm.cavv.value;
		var cardno = frm.CARD_NUMBER.value;

		/* Please process the 302*/
		if(errCode == "302"){
			arg = true;
			frm.eci.value = "06";				//You must set this when you try NON 3D.
			if(cardno.substr(0,1) =="5"){		//MasterCard
				frm.eci.value = "01";
			}
		}
		
		if (arg == "TRUE"||arg == "true"||arg == true){
			frm.submit();//Visa3D Auth 
		}else{
			alert("Visa3D secure failed") ;
		}
	}

	</script>
	</head>

<body >
	<form name="payment" action ="<?echo($NEXT_URL)?>" name="trustpay" method="POST">
	<table align="center" border="0" cellpadding="10" cellspacing="0" bgcolor="#000033" style="border-width:1; border-style:solid;">
	  <tr> 
		<td height="113" bordercolor="#000033" bgcolor="#FFFFFF" align="center" valign="center"><font color="red"><b>3D TEST</b></font><br><br>
		<b>SamplePage</b><br><br>
		<table border="0" style="border-width:1; border-style:solid;">
			<tr>
				<td colspan="2" align="center"><font color="blue">Credit Card Test Form</font><br/><br/>
					<!--Visa3d---------------------------------------------------------------->
					<input type="hidden" name="xid"		value="">
					<input type="hidden" name="eci"		value="">
					<input type="hidden" name="cavv"	value="">
					<!--Visa3d---------------------------------------------------------------->

					<!-- Payment Element -->
					<input type="hidden" name="TRN_TYPE"	value="<?echo($TRN_TYPE)?>">
					<input type="hidden" name="RES_TYPE"	value="<?echo($RES_TYPE)?>">
					<input type="hidden" name="SERVICE_TYPE"	value="<?echo($SERVICE_TYPE)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;CARD NUMBER</p>
				</td>			
				<td>
					<input type="text" name="CARD_NUMBER" maxlength="16" size="50" value="<?echo($CARD_NUMBER)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;EXPIRY</p>
				</td>			
				<td>
					<input type="text" name="CARD_EXPIRE" maxlength="50" size="50" value="<?echo($CARD_EXPIRE)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;PAYNO</p>
				</td>			
				<td>
					<input type="text" name="PAY_NO" maxlength="50" size="50" value="<?echo($PAY_NO)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;PAYEMAIL</p>
				</td>			
				<td>
					<input type="text" name="PAY_EMAIL" maxlength="50" size="50" value="<?echo($PAY_EMAIL)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;PAYNAME</p>
				</td>			
				<td>
					<input type="text" name="PAY_NAME" maxlength="50" size="50" value="<?echo($PAY_NAME)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;PAYTELNO</p>
				</td>			
				<td>
					<input type="text" name="PAY_TELNO" maxlength="50" size="50" value="<?echo($PAY_TELNO)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;AMOUNT (USD) $1.1 &gt;110</p>
				</td>			
				<td>
					<input type="text" name="AMOUNT" maxlength="50" value="<?echo($AMOUNT)?>" size="50">&nbsp;
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;CUR_TYPE&gt;110</p>
				</td>			
				<td>
					<input type="text" name="CUR_TYPE" maxlength="50" value="<?echo($CUR_TYPE)?>" size="50">&nbsp;
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;PRODUCTTYPE</p>
				</td>			
				<td>
					<input type="text" name="PRODUCT_TYPE" maxlength="50" size="50" value="<?echo($PRODUCT_TYPE)?>">
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;PRODUCTNAME</p>
				</td>			
				<td>
					<input type="text" name="PRODUCT_NAME" maxlength="50" size="50" value="<?echo($PRODUCT_NAME)?>">&nbsp;
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;MERCHANT_ID</p>
				</td>			
				<td>
					<input type="text" name="MERCHANT_ID" maxlength="50" size="50" value="<?echo($MERCHANT_ID)?>">
					
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;IP_ADDRESS</p>
				</td>			
				<td>
					<input type="text" name="IP_ADDRESS" maxlength="50" size="50" value="<?echo($IP_ADDRESS)?>">
					
				</td>
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;MALL_ID</p>
				</td>			
				<td>
					<input type="text" name="MALL_ID" maxlength="50" size="50" value="<?echo($MALL_ID)?>">
					
				</td>
			</tr>
			<tr>
				<td colspan="2">&nbsp;
				</td>			
			</tr>
			<tr>
				<td width="168" align="right">
					<p>&nbsp;<font color="red">Execute Payment:</font></p>
				</td>			
				<td align ="center">
					<input type="button" value="3D EXECUTE" size="20" onclick="javascript:submit3d();" >
				</td>
			</tr>
		 </table>
		 </td>
	  </tr>
	  <tr> 
		<td bordercolor="#000000" bgcolor="#003366" align="center" height="3">
		</td>
	  </tr>
	</table>
	</form>
	<!------------------------------------ ILK Modification --------------------------------------------->
	<!-----------------------------------------------------------------------------------------------
		Notice!
		The reason for leaving blank of dummy.jsp is prevent to secure issue massage showing up when you
                try to make secure payment. Or else you will get the unnecessary massage on the loading the page.
                If you delete this part, you will get the massage confirmation massage about secure issue.
                Please do not edit or change below sector.
	------------------------------------------------------------------------------------------------->

	<!--Parameters for Visa3d-->
	<IFRAME id=ILKFRAME name=ILKFRAME style="display:none" src="blank.html"></IFRAME>

	<div style="display:none"> 
	<FORM name=Visa3d action="<%=WMPI_ILK_HOST%>"  target="ILKFRAME" method=post>
		<INPUT type="hidden"		name="returnUrl"		value=""					>	
		<INPUT type="hidden"		name=pan				value=""					>
		<INPUT type="hidden"		name=expiry				value=""					>
		<INPUT type="hidden"		name=purchase_amount	value=""		>
		<INPUT type="hidden"		name=amount				value=""			>
		<INPUT type="hidden"		name=exponent			value="2"	>
		<INPUT type="hidden"		name=currency			value="840"	>
		<INPUT type="hidden"		name=recur_frequency	value=""					>
		<INPUT type="hidden"		name=recur_expiry		value=""					>
		<INPUT type="hidden"		name=userid				value=""					>
		<INPUT type="hidden"		name=transID			value=""					>
		<INPUT type="password"		name="dummy"			value=""					>
		<INPUT type="hidden"		name="country"			value="410"					>
		<INPUT type="hidden"		name=installments		value=""					>   
		<INPUT type="hidden"		name="name"				value="MERCHANTNAME"			>
		<INPUT type="hidden"		name="url"				value="DOMAIN">	
		<INPUT type="hidden"		name=hostid				value="00000111"	>
		<INPUT type="hidden"		name=hostpwd			value="ksnetdkagh"	>
		<INPUT type="hidden"		name=description		value="NONE"				>
		<INPUT type="hidden"		name=device_category	value="0"					>
		<INPUT type="hidden"		name=useActiveX			value="0"					>
		<input type="hidden"		name="instType"			value=""					>
		<input type="hidden"		name=cardcode			value=""					>
		<input type="hidden"		name="bizNo"			value="1178178843"			> <!-- KEB BIZNO -->
		<input type="hidden"		name="merInfo"			value="2288100001">		<!-- MERCHANT ID -->
			
	</FORM>
	</div>
<!------------------------------------ ILK Modification end ----------------------------------------->
</body>
</html>
