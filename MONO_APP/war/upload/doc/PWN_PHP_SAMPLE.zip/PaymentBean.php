 <?

/**
*
* PaymentBean modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
**/

class PaymentBean
{
	var $msg;
	var $cardNumber;		//CARD NUMBER
	var $cardExpire;		//CARD EXPIRY( format : YYMM )
	var $cardCVV;			//CARD CVV NUMBER 
	var $cardPassword ;		//CARD PASSWORD
	var $cardExtra;			//CARD ETC 
	var $payUserId;			//Payment User ID   ( English)
	var $payName;			//Payment User Name ( English)
	var $payTelNo;			//Payment User Tel Number
	var $payEmail;			//Payment User Email
	var $productType;		//Payment Product Type ( 0:product,1:contents)
	var $productName;		//Payment Product Name
	var $amount;			//Payment Amount
	var $curType;			//Currency Type ( USD ,JPY )
	var $approvalNo;		//Approval Number
	var $extra;
	
  /* Constractor */
  function PaymentBean(){
	
  }
  
  function toString() { 
		return         
	   str_pad($this->cardNumber		,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardExpire		, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardCVV			, 3, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardPassword		, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardExtra			,10, " ", STR_PAD_RIGHT)
	 . str_pad($this->payUserId			,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->payName			,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->payTelNo			,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->payEmail			,100," ", STR_PAD_RIGHT)
	 . str_pad($this->productType		, 2, " ", STR_PAD_RIGHT)
	 . str_pad($this->productName		,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->amount			,10, "0", STR_PAD_LEFT)
	 . str_pad($this->curType			, 3, " ", STR_PAD_RIGHT)
	 . str_pad($this->approvalNo		, 8, " ", STR_PAD_RIGHT)
	 . str_pad($this->extra				,66, " ", STR_PAD_RIGHT);
  } 	
  
  function setString($msg) { 
     $this->msg = $msg;
	 $this->setCardNumber(trim($this->nextdata(20)));	
	 $this->setCardExpire(trim($this->nextdata(4)));	
	 $this->setCardCVV(trim($this->nextdata(3)));	
	 $this->setCardPassword(trim($this->nextdata(4)));	
	 $this->setCardExtra(trim($this->nextdata(10)));	
	 $this->setPayUserId(trim($this->nextdata(50)));	
	 $this->setPayName(trim($this->nextdata(50)));	
	 $this->setPayTelNo(trim($this->nextdata(20)));	
	 $this->setPayEmail(trim($this->nextdata(100)));	
	 $this->setProductType(trim($this->nextdata(2)));	 
	 $this->setProductName(trim($this->nextdata(50)));	
	 $this->setAmount(trim($this->nextdata(10)));		
	 $this->setCurType(trim($this->nextdata(3)));		
	 $this->setApprovalNo(trim($this->nextdata(8)));		
	 $this->setExtra(trim($this->nextdata(66)));	

  } 	  

	
	function nextdata($size) {
		$data = substr($this->msg,0,$size);
		$this->msg = substr($this->msg,$size);
		return $data;
	}

	function getMsg() {
		return $this->msg;
	}
	function setMsg($msg) {
		$this->msg = $msg;
	}
	function getCardNumber() {
		return $this->cardNumber;
	}
	function setCardNumber($cardNumber) {
		$this->cardNumber = $cardNumber;
	}
	function getCardExpire() {
		return $this->cardExpire;
	}
	function setCardExpire($cardExpire) {
		$this->cardExpire = $cardExpire;
	}
	function getCardCVV() {
		return $this->cardCVV;
	}
	function setCardCVV($cardCVV) {
		$this->cardCVV = $cardCVV;
	}
	function getCardPassword() {
		return $this->cardPassword;
	}
	function setCardPassword($cardPassword) {
		$this->cardPassword = $cardPassword;
	}
	function getCardExtra() {
		return $this->cardExtra;
	}
	function setCardExtra($cardExtra) {
		$this->cardExtra = $cardExtra;
	}
	function getPayUserId() {
		return $this->payUserId;
	}
	function setPayUserId($payUserId) {
		$this->payUserId = $payUserId;
	}
	function getPayName() {
		return $this->payName;
	}
	function setPayName($payName) {
		$this->payName = $payName;
	}
	function getPayTelNo() {
		return $this->payTelNo;
	}
	function setPayTelNo($payTelNo) {
		$this->payTelNo = $payTelNo;
	}
	function getPayEmail() {
		return $this->payEmail;
	}
	function setPayEmail($payEmail) {
		$this->payEmail = $payEmail;
	}
	function getProductType() {
		return $this->productType;
	}
	function setProductType($productType) {
		$this->productType = $productType;
	}
	function getProductName() {
		return $this->productName;
	}
	function setProductName($productName) {
		$this->productName = $productName;
	}
	function getAmount() {
		return $this->amount;
	}
	function setAmount($amount) {
		$this->amount = $amount;
	}
	function getCurType() {
		return $this->curType;
	}
	function setCurType($curType) {
		$this->curType = $curType;
	}
	function getApprovalNo() {
		return $this->approvalNo;
	}
	function setApprovalNo($approvalNo) {
		$this->approvalNo = $approvalNo;
	}
	function getExtra() {
		return $this->extra;
	}
	function setExtra($extra) {
		$this->extra = $extra;
	}
	
  
	
}	

 ?>
 
