<?php

	/* Generate Header Packet*/
	$TRN_TYPE = "T001";
	$MERCHANT_ID = "";
	$MALL_ID = "";
	$SERVICE_TYPE = "WEB";
	$IP_ADDRESS = "127.0.0.1";
	$TRN_DATE = date("YmdHis");
	$PAY_NO = date("YmdHis");
	$RES_TYPE = "TEXT";


	/* Generate Payment Packet*/


	$CARD_NUMBER =""; //CARD NUMBER	
	$CARD_EXPIRE =""; //YYMM
	$CARD_CVV = "";
	$CARD_PASSWORD = "";
	$CARD_EXTRA = "";
	$PAY_USERID = "USERID";
	$PAY_NAME = "USERNAME";
	$PAY_TELNO = "0234463730";
	$PAY_EMAIL = "ginaida@trustmate.net";
	$PRODUCT_TYPE = "1";
	$PRODUCT_NAME = "TEST PRODUCT";
	$CUR_TYPE = "USD";
	$AMOUNT = "110"; // 1.1 $
	$DOMAIN = "localhost";
	$FORNAME = "John";		
	$SURNAME = "Doe";
	$ADDR1 = "1295 Charleston Road";
	$ADDR2 = "Mountain View";
	$STATE = "CA";
	$COUNTRY = "US";
	$ZIP = "94043";


	$result = "";


	$post_data = array(
						'TRN_TYPE' => $TRN_TYPE,
						'MERCHANT_ID' => $MERCHANT_ID,
						'MALL_ID' => $MALL_ID, 
						'SERVICE_TYPE' => $SERVICE_TYPE,
						'IP_ADDRESS' => $IP_ADDRESS, 
						'TRN_DATE' => $TRN_DATE,
						'PAY_NO' => $PAY_NO, 
						'RES_TYPE' => $RES_TYPE,
						'CARD_NUMBER' => $CARD_NUMBER, 
						'CARD_EXPIRE' => $CARD_EXPIRE,
						'CARD_CVV' =>  $CARD_CVV,
						'CARD_PASSWORD' => $CARD_PASSWORD, 
						'CARD_EXTRA' => $CARD_EXTRA,
						'PAY_USERID' => $PAY_USERID, 
						'PAY_NAME' => $PAY_NAME, 
						'PAY_TELNO' => $PAY_TELNO, 
						'PAY_EMAIL' => $PAY_EMAIL, 
						'PRODUCT_TYPE' => $PRODUCT_TYPE, 
						'PRODUCT_NAME' => $PRODUCT_NAME,
						'CUR_TYPE' => $CUR_TYPE,
						'AMOUNT' => $AMOUNT,
						'DOMAIN' => $DOMAIN,
						'FORNAME' => $FORNAME, 
						'SURNAME' => $SURNAME, 
						'ADDR1' => $ADDR1, 
						'ADDR2' => $ADDR2, 
						'STATE' => $STATE, 
						'COUNTRY' => $COUNTRY, 
						'ZIP' => $ZIP
				  );

	$post_query = http_build_query($post_data);

	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_URL, "https://service.pgmate.com/payment.do");
	curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 300);  
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_REFERER']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_query);
	$result = curl_exec($ch);
	$err = curl_error($ch);

	curl_close($ch);

	$dataArray = explode('&', $result);
	$size = sizeof($dataArray);
	for($i = 0 ; $i < $size ; $i++){
		echo $dataArray[$i]."<br/>";
	}

?>
