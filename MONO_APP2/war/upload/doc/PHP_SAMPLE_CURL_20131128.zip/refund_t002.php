<?php
	
	/* Generate Header Packet*/
	$TRN_TYPE = "T002";
	$MERCHANT_ID = "";
	$MALL_ID = "";
	$SERVICE_TYPE = "WEB";
	$IP_ADDRESS = "127.0.0.1";
	$TRN_DATE = date("YmdHis");
	$PAY_NO = "1234567";
	$RES_TYPE = "TEXT";


	/* Generate Payment Packet*/

	$VOID_TYPE = "1";
	$RTRANSACTION_ID = "";
	$APPROVAL_DAY = "";
	$RAPPROVAL_NO = "";
	$RPAY_NO = "";
	$AMOUNT = "";
	$APPROVAL_NO = "";

	$post_data = array(
						'TRN_TYPE' => $TRN_TYPE,
						'MERCHANT_ID' => $MERCHANT_ID,
						'MALL_ID' => $MALL_ID, 
						'SERVICE_TYPE' => $SERVICE_TYPE,
						'IP_ADDRESS' => $IP_ADDRESS, 
						'TRN_DATE' => $TRN_DATE,
						'PAY_NO' => $PAY_NO, 
						'RES_TYPE' => $RES_TYPE,
						'VOID_TYPE' => $VOID_TYPE,
						'RTRANSACTION_ID' => $RTRANSACTION_ID, 
						'APPROVAL_DAY' => $APPROVAL_DAY,
						'RAPPROVAL_NO' =>  $RAPPROVAL_NO,
						'RPAY_NO' => $RPAY_NO, 
						'AMOUNT' => $AMOUNT,
						'APPROVAL_NO' => $APPROVAL_NO
				  );

	$post_query = http_build_query($post_data);

	//echo "Query String = [".$post_query."]";
	
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_URL, "https://service.pgmate.com/payment.do?");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_query);
	$result = curl_exec($ch);
	$err = curl_error($ch);

	curl_close($ch);
	
	$dataArray = explode('&', $result);
	$size = sizeof($dataArray);
	for($i = 0 ; $i < $size ; $i++){
		echo $dataArray[$i]."<br/>";
	}
	

?>
