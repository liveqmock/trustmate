package sample;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class Connect{		
	
	private Socket socket				= null;
	private OutputStream outputStream 	= null;
	private InputStream inputStream		= null;


	public byte[] connect(byte[] request){
		byte[] response = null;
		try{
			System.out.println("C>>GATEWAY =["+new String(request)+"]");
			response = (connect(4, request));
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			System.out.println("C<<GATEWAY =["+new String(response)+"]");
		}
		return response;
	}

	public OutputStream getOutputStream()throws IOException {
		if(socket == null){
			System.out.println("getOutputStream() Error");	
			throw new IOException("socket is null");
		}
		return socket.getOutputStream();
	}
	
	public InputStream getInputStream()throws IOException {
		if(socket == null){
			System.out.println("getInputStream() Error");	
			throw new IOException("socket is null");
		}
		return socket.getInputStream();
	}

	public byte[] connect( int readHeader,byte[] request) throws IOException{
		byte[] response 	= null;
		socket = new Socket();
		try{
			socket.connect(new InetSocketAddress("localhost",20000) ,60000);
			outputStream = getOutputStream();
			send(request);
			inputStream	=  getInputStream();
			
			byte[] totalLen = recv(readHeader);
			int expectLength = Integer.parseInt(new String(totalLen));
			
			response = recv(expectLength);
			response = byteAppend(totalLen,response);
		}catch(IOException io){
			throw new IOException(io.getMessage());
		}finally{
			ioClose();
			socketClose();	
		}
		return response;
	}
	public byte[] recv(int requestLength)throws IOException{
		byte[] recv = new byte[requestLength];
		
		boolean run = true;
		int receivedLength = 0;
		
		while(run){
			byte[] temp = new byte[requestLength-receivedLength];
			int read = inputStream.read(temp);
			arrayCopy(recv, receivedLength,temp,read);
			receivedLength += read;
			if(receivedLength >= requestLength){
				run = false;
			}
		}
		return recv;
	}
	
	public void arrayCopy(Object destBuffer,int destPos,Object srcBuffer,int srcLen){
		System.arraycopy(srcBuffer,0,destBuffer,destPos,srcLen);
	}


	public void send(byte[] response)throws IOException{
		outputStream.write(response,0,response.length);
		outputStream.flush();
	}
	
	public void ioClose() throws IOException{
		if(inputStream != null){ inputStream.close();}
		if(outputStream != null){ outputStream.close();}
	}
	
	
	public void socketClose(){
		if(socket != null){
			try{
				socket.close();
				socket = null;
			}catch(IOException io){
			}
		}
	}
	
	public byte[] byteAppend(byte[] b,byte[] appendByte){
		
		if(b == null && appendByte == null)
			return new byte[0];
		
		if(b == null)
			return appendByte;
		
		if(appendByte == null)
			return b;
		
		if(b == null && appendByte == null)
			return new byte[0];
		
		
		int len = b.length + appendByte.length;
		
		byte[]  nb = new byte[len];
		
		int i = 0;
		for(;i<b.length;i++){
			nb[i] = b[i];
		}
		for(int j=0 ; j < appendByte.length ; j++){
			nb[i] = appendByte[j];
			i++;
		}
		return nb;
	}
	
}