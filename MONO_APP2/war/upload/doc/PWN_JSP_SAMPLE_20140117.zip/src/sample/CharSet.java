package sample;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public class CharSet {
	
	public static String toString(Object object){
		
		if(object == null){
			return "";
		}else{
			if(object instanceof Timestamp){
				return timestampToString((Timestamp)object);
			}else if(object instanceof Integer){
				Integer i = (Integer)object;
				return toString(i.intValue());
			}else if( object instanceof Long ){
				Long l = (Long)object;
				return toString(l.longValue());
			}else if( object instanceof Double){
				Double d = (Double)object;
				return toString(d.doubleValue());
			}else{
				return (String)object;
			}
		}
		
	}
	
	public static String toString(byte[] b){
		return toString(b,0,length(b));
	}
	
	public static String toString(byte[] b,String charSet){
		String s = "";
		try{
			s= new String(b,charSet);
		}catch(Exception e){
			s= toString(b);
		}
		return s;
	}
	
	public static String toString(String s,String charSet){
		try{
			byte[] b = s.getBytes(charSet);
			s= new String(b,charSet);
		}catch(Exception e){
			return "";
		}
		return s;
	}
	
	public static String toString(byte[] b,int init){
		return toString(b,init,b.length-init);
	}
	
	
	public static String toString(byte[] b , int start , int end){	
		
		if(length(b) < start || length(b)==0 )
			return "";
		else if(length(b) < start+end)
			return new String(b,start,length(b));
		else
			return new String(b,start,end);
	}
	
	public static String toStringCharSet(byte[] b , int start , int end,String charSet){	
		
		try{
			b = new String(b,charSet).getBytes();
		}catch(Exception e){
		}

		if(length(b) < start || length(b)==0 )
			return "";
		else if(length(b) < start+end)
			return toString(b,start,length(b));
		else
			return toString(b,start,end);
	}
	
	public static String toString(int i){
		return Integer.toString(i);
	}
	
	public static String toString(long i){
		return Long.toString(i);
	}
	
	public static String toString(double i){
		return Double.toString(i);
	}

	public static String timestampToString(Timestamp timestamp) {
		if (timestamp == null) {
			timestamp = new Timestamp(new java.util.Date().getTime());
		}
		java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		return df.format(new java.util.Date(timestamp.getTime()));
	} 
	
	public static int length(byte[] b){
		if(b == null)
			return 0;
		else
			return b.length;
	}
	
	public static int length(String s){
		if(s == null)
			return 0;	
		else
			return s.length();	
	}
	
	public static String byteFiller(String oldStr,int len) {
		byte[] b 	= oldStr.getBytes();
		int oldLen = b.length;
		
		if(oldLen >= len) 
			return byteTrim(b,len);
		else {
			byte[] nb = new byte[len];
			int i =0 ;
			for( ; i< oldLen ; i++) {
				nb[i] = b[i];
			}
			for( ; i < len ; i++) {
				nb[i] = ' ';
			}
			
			return new String(nb);
		}
	}
	
	public static String byteTrim(byte[] b,int len) {
		byte[] nb = null;
		if(b == null || b.length == 0){
			nb = new byte[len];
			for(int i=0 ; i < len ;i++){
				b[i] = ' ';
			}
			
		}else{
			int oldLen = b.length;
			if(len <= oldLen){
				nb = new byte[len];
				for(int i =0 ; i<len ; i++) {
					nb[i] = b[i];
				}
			}else{
				byte[] l = new byte[len - oldLen];
				for(int i=0 ; i < (len - oldLen);i++){
					l[i] = ' ';
				}
				nb = byteAppend(b,l);
			}
		}
		
		return new String(nb);
	}
	
	public static byte[] byteTrim(String str,int len) {
		byte[] b = str.getBytes();
		
		byte[] nb = byteTrim(b,len).getBytes();
		if(nb.length == len){
			return nb;
		}else{
			byte[] k = new byte[len];
			for(int i =0 ; i< len ; i++){
				k[i] = nb[i];
			}
			return k;
		}
		
	}
	
	public static byte[] byteAppend(byte[] b,byte[] appendByte){
		
		if(b == null && appendByte == null)
			return new byte[0];
		
		if(b == null)
			return appendByte;
		
		if(appendByte == null)
			return b;
		
		if(b == null && appendByte == null)
			return new byte[0];
		
		
		int len = b.length + appendByte.length;
		
		byte[]  nb = new byte[len];
		
		int i = 0;
		for(;i<b.length;i++){
			nb[i] = b[i];
		}
		for(int j=0 ; j < appendByte.length ; j++){
			nb[i] = appendByte[j];
			i++;
		}
		return nb;
	}
	
	public static String zerofill(String str, int size) {
		if(str == null){
			str="";
		}
		if(str.length() > size){
			return str.substring(0,size);
		}
		try {
			NumberFormat nf = NumberFormat.getInstance();
			return zerofill(nf.parse(str), size);
		} catch (Exception e) {
			return zerofill(0,size);
		}

	}
	
	public static String zerofill(int num, int size) {
		return zerofill(new Integer(num), size);
	}
	
	public static String zerofill(long num, int size) {
		return zerofill(new Long(num), size);
	}

	public static String zerofill(Number num, int size) {
		String zero = "";
		for (int i = 0; i < size; i++) {
			zero += "0";
		}
		DecimalFormat df = new DecimalFormat(zero);
		return df.format(num);
	}
	

}
