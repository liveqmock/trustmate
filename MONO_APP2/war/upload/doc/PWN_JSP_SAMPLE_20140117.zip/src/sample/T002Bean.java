
package sample;


public class T002Bean {

	private String voidType		= "";
	private String approvalDay	= "";
	private String rApprovalNo	= "";
	private String rPayNo		= "";
	private String rTransactionId= "";
	private String cardNumber	= "";
	private String cardExpire	= "";
	private String amount		= "";
	private String curType		= "";
	private String approvalNo	= "";
	private String extra		= "";
	
	public T002Bean(){
		
	}
	
	public T002Bean(String transaction){
		this(transaction.getBytes());
	}
	
	public T002Bean(byte[] transaction){
		voidType		= Util.toString(transaction,0,1).trim(); 
		approvalDay		= Util.toString(transaction,1,8).trim();
		rApprovalNo		= Util.toString(transaction,9,8).trim();
		rPayNo			= Util.toString(transaction,17,50).trim();
		rTransactionId	= Util.toString(transaction,67,12).trim();
		cardNumber		= Util.toString(transaction,79,20).trim();
		cardExpire		= Util.toString(transaction,99,4).trim();
		amount			= Util.toString(transaction,103,10).trim();
		curType			= Util.toString(transaction,113,3).trim();
		approvalNo		= Util.toString(transaction,116,8).trim();
		extra			= Util.toString(transaction,124,76).trim();
	}
	
	public String getTransaction(){
		StringBuffer sb = new StringBuffer();
		sb.append(Util.byteFiller(voidType,1));
		sb.append(Util.byteFiller(approvalDay,8 ));
		sb.append(Util.byteFiller(rApprovalNo,8 ));
		sb.append(Util.byteFiller(rPayNo,50 ));
		sb.append(Util.byteFiller(rTransactionId,12 ));
		sb.append(Util.byteFiller(cardNumber,20 ));
		sb.append(Util.byteFiller(cardExpire,4 ));
		sb.append(Util.zerofill(amount,10 ));
		sb.append(Util.byteFiller(curType,3 ));
		sb.append(Util.byteFiller(approvalNo,8 ));
		sb.append(Util.byteFiller(extra,76 ));
		
		return sb.toString();
	}

	public String getVoidType() {
		return voidType;
	}

	public void setVoidType(String voidType) {
		this.voidType = voidType;
	}

	public String getApprovalDay() {
		return approvalDay;
	}

	public void setApprovalDay(String approvalDay) {
		this.approvalDay = approvalDay;
	}

	public String getRApprovalNo() {
		return rApprovalNo;
	}

	public void setRApprovalNo(String approvalNo) {
		rApprovalNo = approvalNo;
	}

	public String getRPayNo() {
		return rPayNo;
	}

	public void setRPayNo(String payNo) {
		rPayNo = payNo;
	}

	public String getRTransactionId() {
		return rTransactionId;
	}

	public void setRTransactionId(String transactionId) {
		rTransactionId = transactionId;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardExpire() {
		return cardExpire;
	}

	public void setCardExpire(String cardExpire) {
		this.cardExpire = cardExpire;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurType() {
		return curType;
	}

	public void setCurType(String curType) {
		this.curType = curType;
	}

	public String getApprovalNo() {
		return approvalNo;
	}

	public void setApprovalNo(String approvalNo) {
		this.approvalNo = approvalNo;
	}

	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}
	
	
}
