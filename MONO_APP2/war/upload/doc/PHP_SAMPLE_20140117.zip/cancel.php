<?php

//Common Parameter
$PAYMENT_URL	="https://service.pgmate.com/payment.do";

$TRN_TYPE		="T002";
$MERCHANT_ID	="";
$MALL_ID		="";
$SERVICE_TYPE	="WEB";
$IP_ADDRESS		=$_SERVER["REMOTE_ADDR"];
$TRN_DATE		=date("YmdHis");
$PAY_NO			=date("YmdHis");
$RES_TYPE		="TEXT";

//Parameter of Credit Card Cancelation
$VOID_TYPE		="1";	//using Transaction Number
$RTRANSACTION_ID="130628002080";	//Initial Transaction Number 



$reqQuery = array(
	'TRN_TYPE' => $TRN_TYPE,
	'MERCHANT_ID' => $MERCHANT_ID,
	'MALL_ID' => $MALL_ID, 
	'SERVICE_TYPE' => $SERVICE_TYPE,
	'IP_ADDRESS' => $IP_ADDRESS, 
	'TRN_DATE' => $TRN_DATE,
	'PAY_NO' => $PAY_NO, 
	'RES_TYPE' => $RES_TYPE,
	'VOID_TYPE' => $VOID_TYPE,
	'RTRANSACTION_ID' => $RTRANSACTION_ID
);

	$ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_URL, $PAYMENT_URL);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 300);  
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_REFERER']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $reqQuery);  
    $resQuery = curl_exec($ch);
    curl_close($ch);
    
	echo '<br/>RESULT DATA<br/><br/>';

	$dataArray = explode('&', $resQuery);
	$size = sizeof($dataArray);
	
	for($i = 0 ; $i < $size ; $i++){
		$data = split('=',$dataArray[$i]);
		if($data[0] !=''){
			echo $data[0].'='.urldecode($data[1])."<br/>";
		}
	}
?>
