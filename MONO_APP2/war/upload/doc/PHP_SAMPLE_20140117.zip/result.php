<?
	$RESULT_CD		= $_POST["RESULT_CD"];
	$RESULT_MSG		= $_POST["RESULT_MSG"];
	$TRANSACTION_ID = $_POST["TRANSACTION_ID"];
	$APPROVAL_NO	= $_POST["APPROVAL_NO"];
	$MESSAGE		= $_POST["MESSAGE"];
	$TRN_RES_DATE	= $_POST["TRN_RES_DATE"];
	$userDefine     = $_GET["userDefine"];

?>
<html>
<body>
	<font color="blue">RESULT_CD =0 &amp; RESULT_MSG =0000 </font></br></br>
	RESULT_CD = <?echo($RESULT_CD)?></br>
	RESULT_MSG = <?echo($RESULT_MSG)?></br> 
	TRANSACTION_ID = <?echo($TRANSACTION_ID)?></br>
	APPROVAL_NO = <?echo($APPROVAL_NO)?></br>
	MESSAGE = <?echo($MESSAGE)?></br>
	TRN_RES_DATE = <?echo($TRN_RES_DATE)?></br>
	userDefine = <?echo($userDefine)?></br>
</body>
</html>