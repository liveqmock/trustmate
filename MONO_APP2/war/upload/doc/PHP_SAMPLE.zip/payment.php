<?php

//Common Parameter
$PAYMENT_URL	="https://service.pgmate.com/payment.do";

$TRN_TYPE		=$_POST['TRN_TYPE'];
$MERCHANT_ID	=$_POST['MERCHANT_ID'];
$MALL_ID		=$_POST['MALL_ID'];
$SERVICE_TYPE	=$_POST['SERVICE_TYPE'];
$IP_ADDRESS		=$_POST['IP_ADDRESS'];
$TRN_DATE		=$_POST['TRN_DATE'];
$PAY_NO			=$_POST['PAY_NO'];
$RES_TYPE		=$_POST['RES_TYPE'];

//Parameter of Credit Card Approval
$CARD_NUMBER	=$_POST['CARD_NUMBER'];			//Credit Card Number
$CARD_EXPIRE	=$_POST['CARD_EXPIRE'];			//Credit Card Expiration Date (YYMM)
$PAY_USERID		=$_POST['PAY_USERID'];			//Merchant User Id (Required)
$PAY_NAME		=$_POST['PAY_NAME'];			//Merchant User Name (Required)
$PAY_TELNO		=$_POST['PAY_TELNO'];			//Merchant User Tel Number (Required)
$PAY_EMAIL		=$_POST['PAY_EMAIL'];			//Merchant User Email (Required)
$PRODUCT_TYPE	=$_POST['PRODUCT_TYPE'];		// "0" : Goods, "1":Contents (Required)
$PRODUCT_NAME	=$_POST['PRODUCT_NAME'];		//Name of Product
$CUR_TYPE		=$_POST['CUR_TYPE'];			//Currency Type (Required)
$AMOUNT			=$_POST['AMOUNT'];				//USD 1.01$ => 101 (Required)
$DOMAIN			=$_POST['DOMAIN']	;			//Merchant URL (Required)

$reqQuery = array(
	'TRN_TYPE' => $TRN_TYPE,
	'MERCHANT_ID' => $MERCHANT_ID,
	'MALL_ID' => $MALL_ID, 
	'SERVICE_TYPE' => $SERVICE_TYPE,
	'IP_ADDRESS' => $IP_ADDRESS, 
	'TRN_DATE' => $TRN_DATE,
	'PAY_NO' => $PAY_NO, 
	'RES_TYPE' => $RES_TYPE,
	'CARD_NUMBER' => $CARD_NUMBER,
	'CARD_EXPIRE' => $CARD_EXPIRE,
	'PAY_USERID' => $PAY_USERID,
	'PAY_NAME' => $PAY_NAME,
	'PAY_TELNO' => $PAY_TELNO,
	'PAY_EMAIL' => $PAY_EMAIL,
	'PRODUCT_TYPE' => $PRODUCT_TYPE,
	'PRODUCT_NAME' => $PRODUCT_NAME,
	'CUR_TYPE' => $CUR_TYPE,
	'AMOUNT' => $AMOUNT,
	'DOMAIN' => $DOMAIN
);

	$ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_URL, $PAYMENT_URL);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 300);  
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_REFERER, $_SERVER['HTTP_REFERER']);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $reqQuery);  
    $resQuery = curl_exec($ch);
    curl_close($ch);
    
	echo '<br/>RESULT DATA<br/><br/>';

	$dataArray = explode('&', $resQuery);
	$size = sizeof($dataArray);
	
	for($i = 0 ; $i < $size ; $i++){
		$data = split('=',$dataArray[$i]);
		if($data[0] !=''){
			echo $data[0].'='.urldecode($data[1])."<br/>";
		}
	}
?>
