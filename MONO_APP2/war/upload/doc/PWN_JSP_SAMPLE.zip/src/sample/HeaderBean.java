
package sample;

public class HeaderBean {
	private String specLength	= "";
	private String specType		= "";
	private String trnType		= "";
	private String merchantId	= "";
	private String mallId		= "";
	private String serviceType	= "";
	private String ipAddress	= "";
	private String trnDate		= "";
	private String trnResDate	= "";
	private String payNo		= "";
	private String transactionId= "";
	private String resultCd		= "";
	private String resultMsg	= "";
	private String extra		= "";
	
	
	public HeaderBean(){	
	}
	
	public HeaderBean(String transaction){
		this(transaction.getBytes());
	}
	
	public HeaderBean(byte[] transaction){
		specLength		= Util.toString(transaction,0,4).trim();
		specType		= Util.toString(transaction,4,4).trim();
		trnType			= Util.toString(transaction,8,4).trim();
		merchantId		= Util.toString(transaction,12,20).trim();
		mallId			= Util.toString(transaction,32,20).trim();
		serviceType		= Util.toString(transaction,52,8).trim();
		ipAddress		= Util.toString(transaction,60,20).trim();
		trnDate			= Util.toString(transaction,80,14).trim();
		trnResDate		= Util.toString(transaction,94,14).trim();
		payNo			= Util.toString(transaction,108,50).trim();
		transactionId	= Util.toString(transaction,158,12).trim();
		resultCd		= Util.toString(transaction,170,1).trim();
		resultMsg		= Util.toString(transaction,171,4).trim();
		extra			= Util.toString(transaction,175,25).trim();
	}
	
	public String getTransaction(byte[] transaction){
		return getTransaction(Util.toString(transaction));
	}
	
	public String getTransaction(String transaction){
		StringBuffer sb = new StringBuffer();
		specLength = Util.toString(200-4+transaction.getBytes().length);
		sb.append(Util.zerofill(specLength,4));
		sb.append(Util.byteFiller(specType,4));
		sb.append(Util.byteFiller(trnType,4));
		sb.append(Util.byteFiller(merchantId,20));
		sb.append(Util.byteFiller(mallId,20));
		sb.append(Util.byteFiller(serviceType,8));
		sb.append(Util.byteFiller(ipAddress,20));
		sb.append(Util.byteFiller(trnDate,14));
		sb.append(Util.byteFiller(trnResDate,14));
		sb.append(Util.byteFiller(payNo,50));
		sb.append(Util.byteFiller(transactionId,12));
		sb.append(Util.byteFiller(resultCd,1));
		sb.append(Util.byteFiller(resultMsg,4));
		sb.append(Util.byteFiller(extra,25));
		sb.append(transaction);
		return sb.toString();
	}

	public String getSpecLength() {
		return specLength;
	}


	public void setSpecLength(String specLength) {
		this.specLength = specLength;
	}


	public String getSpecType() {
		return specType;
	}


	public void setSpecType(String specType) {
		this.specType = specType;
	}


	public String getTrnType() {
		return trnType;
	}


	public void setTrnType(String trnType) {
		this.trnType = trnType;
	}


	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getMallId() {
		return mallId;
	}


	public void setMallId(String mallId) {
		this.mallId = mallId;
	}


	public String getServiceType() {
		return serviceType;
	}


	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}


	public String getIpAddress() {
		return ipAddress;
	}


	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}


	public String getTrnDate() {
		return trnDate;
	}


	public void setTrnDate(String trnDate) {
		this.trnDate = trnDate;
	}


	public String getTrnResDate() {
		return trnResDate;
	}


	public void setTrnResDate(String trnResDate) {
		this.trnResDate = trnResDate;
	}


	public String getPayNo() {
		return payNo;
	}


	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public String getResultCd() {
		return resultCd;
	}


	public void setResultCd(String resultCd) {
		this.resultCd = resultCd;
	}


	public String getResultMsg() {
		return resultMsg;
	}


	public void setResultMsg(String resultMsg) {
		this.resultMsg = resultMsg;
	}


	public String getExtra() {
		return extra;
	}


	public void setExtra(String extra) {
		this.extra = extra;
	}
}
