 <?

/**
*
* PaymentBean modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
**/

class PaymentBean
{
	var $msg;
	var $cardNumber;		//CARD NUMBER
	var $cardExpire;		//CARD EXPIRY( format : YYMM )
	var $cardCVV;			//CARD CVV NUMBER 
	var $cardPassword ;		//CARD PASSWORD
	var $cardExtra;			//CARD ETC 
	var $payUserId;			//Payment User ID   ( English)
	var $payName;			//Payment User Name ( English)
	var $payTelNo;			//Payment User Tel Number
	var $payEmail;			//Payment User Email
	var $productType;		//Payment Product Type ( 0:product,1:contents)
	var $productName;		//Payment Product Name
	var $amount;			//Payment Amount
	var $curType;			//Currency Type ( USD ,JPY )
	var $approvalNo;		//Approval Number
	var $domain;			//Web Site Domain
	var $cavv;				//cavv[40]+xid[40]+eci[2]
	var $extra;	
	var $foreName;
	var $surName;
	var $addr1;
	var $addr2;
	var $city;
	var $state;
	var $country;
	var $zip;
	
  /* Constractor */
  function PaymentBean(){
	
  }
  
  function toString() { 
		return         
	   str_pad($this->cardNumber		,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardExpire		, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardCVV			, 3, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardPassword		, 4, " ", STR_PAD_RIGHT)
	 . str_pad($this->cardExtra			,10, " ", STR_PAD_RIGHT)
	 . str_pad($this->payUserId			,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->payName			,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->payTelNo			,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->payEmail			,100," ", STR_PAD_RIGHT)
	 . str_pad($this->productType		, 2, " ", STR_PAD_RIGHT)
	 . str_pad($this->productName		,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->amount			,10, "0", STR_PAD_LEFT)
	 . str_pad($this->curType			, 3, " ", STR_PAD_RIGHT)
	 . str_pad($this->approvalNo		, 8, " ", STR_PAD_RIGHT)
	 . str_pad($this->domain			,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->cavv				,100, " ", STR_PAD_RIGHT)
	 . str_pad($this->extra				,66, " ", STR_PAD_RIGHT)
	 . str_pad($this->foreName			,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->surName			,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->addr1				,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->addr2				,50, " ", STR_PAD_RIGHT)
	 . str_pad($this->city				,20, " ", STR_PAD_RIGHT)
	 . str_pad($this->state				,10, " ", STR_PAD_RIGHT)
	 . str_pad($this->country			,2, " ", STR_PAD_RIGHT)
	 . str_pad($this->zip				,9, " ", STR_PAD_RIGHT);
  } 	
  
  function setString($msg) { 
     $this->msg = $msg;
	 $this->setCardNumber(trim($this->nextdata(20)));	
	 $this->setCardExpire(trim($this->nextdata(4)));	
	 $this->setCardCVV(trim($this->nextdata(3)));	
	 $this->setCardPassword(trim($this->nextdata(4)));	
	 $this->setCardExtra(trim($this->nextdata(10)));	
	 $this->setPayUserId(trim($this->nextdata(50)));	
	 $this->setPayName(trim($this->nextdata(50)));	
	 $this->setPayTelNo(trim($this->nextdata(20)));	
	 $this->setPayEmail(trim($this->nextdata(100)));	
	 $this->setProductType(trim($this->nextdata(2)));	 
	 $this->setProductName(trim($this->nextdata(50)));	
	 $this->setAmount(trim($this->nextdata(10)));		
	 $this->setCurType(trim($this->nextdata(3)));		
	 $this->setApprovalNo(trim($this->nextdata(8)));	
	 $this->setDomain(trim($this->nextdata(50)));	
	 $this->setCavv(trim($this->nextdata(100)));	
	 $this->setExtra(trim($this->nextdata(66)));
	 $this->setForeName(trim($this->nextdata(20)));	 
	 $this->setSurName(trim($this->nextdata(20)));	
	 $this->setAddr1(trim($this->nextdata(50)));		
	 $this->setAddr2(trim($this->nextdata(50)));		
	 $this->setCity(trim($this->nextdata(20)));	
	 $this->setState(trim($this->nextdata(10)));	
	 $this->setCountry(trim($this->nextdata(2)));	
	 $this->setZip(trim($this->nextdata(9)));		 

  } 	  

	
	function nextdata($size) {
		$data = substr($this->msg,0,$size);
		$this->msg = substr($this->msg,$size);
		return $data;
	}

	function getMsg() {
		return $this->msg;
	}
	function setMsg($msg) {
		$this->msg = $msg;
	}
	function getCardNumber() {
		return $this->cardNumber;
	}
	function setCardNumber($cardNumber) {
		$this->cardNumber = $cardNumber;
	}
	function getCardExpire() {
		return $this->cardExpire;
	}
	function setCardExpire($cardExpire) {
		$this->cardExpire = $cardExpire;
	}
	function getCardCVV() {
		return $this->cardCVV;
	}
	function setCardCVV($cardCVV) {
		$this->cardCVV = $cardCVV;
	}
	function getCardPassword() {
		return $this->cardPassword;
	}
	function setCardPassword($cardPassword) {
		$this->cardPassword = $cardPassword;
	}
	function getCardExtra() {
		return $this->cardExtra;
	}
	function setCardExtra($cardExtra) {
		$this->cardExtra = $cardExtra;
	}
	function getPayUserId() {
		return $this->payUserId;
	}
	function setPayUserId($payUserId) {
		$this->payUserId = $payUserId;
	}
	function getPayName() {
		return $this->payName;
	}
	function setPayName($payName) {
		$this->payName = $payName;
	}
	function getPayTelNo() {
		return $this->payTelNo;
	}
	function setPayTelNo($payTelNo) {
		$this->payTelNo = $payTelNo;
	}
	function getPayEmail() {
		return $this->payEmail;
	}
	function setPayEmail($payEmail) {
		$this->payEmail = $payEmail;
	}
	function getProductType() {
		return $this->productType;
	}
	function setProductType($productType) {
		$this->productType = $productType;
	}
	function getProductName() {
		return $this->productName;
	}
	function setProductName($productName) {
		$this->productName = $productName;
	}
	function getAmount() {
		return $this->amount;
	}
	function setAmount($amount) {
		$this->amount = $amount;
	}
	function getCurType() {
		return $this->curType;
	}
	function setCurType($curType) {
		$this->curType = $curType;
	}
	function getApprovalNo() {
		return $this->approvalNo;
	}
	function setApprovalNo($approvalNo) {
		$this->approvalNo = $approvalNo;
	}
	function getCavv() {
		return $this->cavv;
	}
	function setCavv($cavv) {
		$this->cavv = $cavv;
	}
	function getDomain() {
		return $this->domain;
	}
	function setDomain($domain) {
		$this->domain = $domain;
	}
	
	function getExtra() {
		return $this->extra;
	}
	function setExtra($extra) {
		$this->extra = $extra;
	}
	
	function getForeName() {
		return $this->foreName;
	}
	function setForeName($foreName) {
		$this->foreName = $foreName;
	}

	function getSurName() {
		return $this->surName;
	}
	function setSurName($surName) {
		$this->surName = $surName;
	}

	function getAddr1() {
		return $this->addr1;
	}
	function setAddr1($addr1) {
		$this->addr1 = $addr1;
	}

	function getAddr2() {
		return $this->addr2;
	}
	function setAddr2($addr2) {
		$this->addr2 = $addr2;
	}

	function getCity() {
		return $this->city;
	}
	function setCity($city) {
		$this->city = $city;
	}

	function getState() {
		return $this->state;
	}
	function setState($state) {
		$this->state = $state;
	}

	function getCountry() {
		return $this->country;
	}
	function setCountry($country) {
		$this->country = $country;
	}

	function getZip() {
		return $this->zip;
	}
	function setZip($zip) {
		$this->zip = $zip;
	}
  
	
}	

 ?>
 
