<?php

/**
*
* Authenticaton modules
*
* @copyright PanWorld Network Inc.,
* @author Juseop Lim
* @modify 
* @version 1.0
*
* Please edit this configuration PWN_GATEWAY/conf/service.xml 
* Need to modify the information below to service.xml is normally available for testing.
* PANWORLD NETWORK REAL SERVER = app.monohitech.com
* PANWORLD NETWORK SERVER PORT = 20000
* Please send to me your ip address (redsy@monohiech.com)
* The Authentication will be forward to T004, and it will be autommatically cancelled in five minutes.
* When you want to cancel manually, plesae use T002.
**/

require_once('SocketClient.php');
require_once('HeaderBean.php');
require_once('AuthBean.php');
require_once('class_oolog.php');

/* define PanWorld server infomation */
$Payment_Host = "localhost";	//local PWN(GSI)_GATEWAY IP
$Payment_Port = 20000;			//local PWN(GSI)_GATEWAY PORT



/* Log */
$datum=date("Y-m-d");
$l=& new oolog("./".$datum.".log", FILE | SCREEN |APPEND);
$l->log("debugging with default values", DEBUG);


/* Generate HeaderBean Packet*/
$headerBean = new HeaderBean();
$headerBean->setSpecLength("0496");				//Anthentication Packet Size : 0496 (FIXED)
$headerBean->setSpecType("CFIX");				//CFIX (FIXED)
$headerBean->setTrnType("T004");				//T004: Request Authentication
$headerBean->setMerchantId("");			//Merchant Id ( please contact manager )
$headerBean->setMallId("");			//Sub MALL ID ( your MerchantID or Sub Merchant ID)
$headerBean->setServiceType("WEB");				//Merchant Order Number		
$headerBean->setIpAddress("127.0.0.1");			//Merchant Customer Name ( please input in English )
$headerBean->setTrnDate(date("YmdHis"));		//Merchant Customer EMail Address
$headerBean->setTrnResDate("");					//Merchant Customer PhoneNumber		
$headerBean->setPayNo(date("YmdHis"));			//Merchant Order Number or Reference Number or TrackingOrderNumber
$headerBean->setTransactionId("");				//TransactionId by PanWorldNetwork
$headerBean->setResultCd("");					//Transaction Result Cd 0:Success, 1: Failure, 2: Error
$headerBean->setResultMsg("");					//Transaction Result Code 
$headerBean->setExtra("");						//User Information (echo field)

/* Generate RefundBean Packet*/
$authBean = new AuthBean();
$authBean->setAuthType("A");					//AUTH TYPE = A
$authBean->setCardNumber("");					//CARD NUMBER
$authBean->setCardExpire("");					//CARD EXPIRY
$authBean->setCardCvv("");						//AUTH TYPE = B , CVV OR CVC
$authBean->setCardPassword("");					//AUTH TYPE = C , First two digit of Pin number
$authBean->setCardFiller("");
$authBean->setPayName("");						//CARDHOLDER NAME
$authBean->setPayTelno("");						//CARDHOLDER TEL NUMBER
$authBean->setMessage("");						//response message of Authentication Service 



echo "<br/>req ==> [".$headerBean->toString().$authBean->toString()."]";
$l->log("req ==> [".$headerBean->toString().$authBean->toString()."]", FILE, false, __LINE__);


/* Connect and receive data */

$socketClient = new SocketClient();
$socketClient->debug = TRUE;
if (!$socketClient->pwn_connect($Payment_Host,$Payment_Port)){
	$l->log("Cannot connect destination", FILE, false, __LINE__);
	die("Cannot connect\n");
}
$data = $socketClient->pwn_send($headerBean->toString().$authBean->toString(), 500); 
$l->log("res ==> [".$data."]" , FILE, false, __LINE__);
echo "<br/>res ==> [".$data."]";
$socketClient->quit();

$headerBean->setString($data);
$authBean->setString(substr($data,200));

if($headerBean->getResultCd() == '0'){
	$l->log("Auth  Succeed", FILE, false, __LINE__);
	echo "<br/>Authentication  Succeed";
}else if($headerBean->getResultCd() == '1'){
	$l->log("Auth Failure ResultMsg=".$headerBean->getResultMsg(), FILE, false, __LINE__);
	echo "<br/>Auth Failure ResultMsg=".$headerBean->getResultMsg();
	echo "<br/>message =".$authBean->getMessage();
}else{
	echo "<br/>System Error retry again";
}


$l->log("=========== HEADER BEAN =========== ", FILE, false, __LINE__);
$l->log("specLength =".$headerBean->getSpecLength(), FILE, false, __LINE__);
$l->log("specType =".$headerBean->getSpecType(), FILE, false, __LINE__);
$l->log("trnType =".$headerBean->getTrnType(), FILE, false, __LINE__);
$l->log("merchantId =".$headerBean->getMerchantId(), FILE, false, __LINE__);
$l->log("mallId =".$headerBean->getMallId(), FILE, false, __LINE__);
$l->log("serviceType =".$headerBean->getServiceType(), FILE, false, __LINE__);
$l->log("ipAddress =".$headerBean->getIpAddress(), FILE, false, __LINE__);
$l->log("trnDate =".$headerBean->getTrnDate(), FILE, false, __LINE__);
$l->log("trnResDate =".$headerBean->getTrnResDate(), FILE, false, __LINE__);
$l->log("payNo =".$headerBean->getPayNo(), FILE, false, __LINE__);
$l->log("TransactionId =".$headerBean->getTransactionId(), FILE, false, __LINE__);
$l->log("resultCd =".$headerBean->getResultCd(), FILE, false, __LINE__);
$l->log("resultMsg =".$headerBean->getResultMsg(), FILE, false, __LINE__);
$l->log("extra =".$headerBean->getExtra(), FILE, false, __LINE__);
$l->log("=========== AUTH BEAN =========== ", FILE, false, __LINE__);
$l->log("authType =".$authBean->getAuthType(), FILE, false, __LINE__);
$l->log("cardNumber =".$authBean->getCardNumber(), FILE, false, __LINE__);
$l->log("cardExpire =".$authBean->getCardExpire(), FILE, false, __LINE__);
$l->log("cardCvv =".$authBean->getCardCvv(), FILE, false, __LINE__);
$l->log("cardPassword =".$authBean->getCardPassword(), FILE, false, __LINE__);
$l->log("cardFiller =".$authBean->getCardFiller(), FILE, false, __LINE__);
$l->log("payName =".$authBean->getPayName(), FILE, false, __LINE__);
$l->log("payTelno =".$authBean->getPayTelno(), FILE, false, __LINE__);
$l->log("message =".$authBean->getMessage(), FILE, false, __LINE__);


echo "<br/>=========== HEADER BEAN =========== ";
echo "<br/>specLength =".$headerBean->getSpecLength();
echo "<br/>specType =".$headerBean->getSpecType();
echo "<br/>trnType =".$headerBean->getTrnType();
echo "<br/>merchantId =".$headerBean->getMerchantId();
echo "<br/>mallId =".$headerBean->getMallId();
echo "<br/>serviceType =".$headerBean->getServiceType();
echo "<br/>ipAddress =".$headerBean->getIpAddress();
echo "<br/>trnDate =".$headerBean->getTrnDate();
echo "<br/>trnResDate =".$headerBean->getTrnResDate();
echo "<br/>payNo =".$headerBean->getPayNo();
echo "<br/>TransactionId =".$headerBean->getTransactionId();
echo "<br/>resultCd =".$headerBean->getResultCd();
echo "<br/>resultMsg =".$headerBean->getResultMsg();
echo "<br/>extra =".$headerBean->getExtra();
echo "<br/>=========== AUTH BEAN =========== ";
echo "<br/>authType =".$authBean->getAuthType();
echo "<br/>cardNumber =".$authBean->getCardNumber();
echo "<br/>cardExpire =".$authBean->getCardExpire();
echo "<br/>cardCvv =".$authBean->getCardCvv();
echo "<br/>cardPassword =".$authBean->getCardPassword();
echo "<br/>cardFiller =".$authBean->getCardFiller();
echo "<br/>payName =".$authBean->getPayName();
echo "<br/>payTelno =".$authBean->getPayTelno();
echo "<br/>message =".$authBean->getMessage();



$l->closelog();

?>

 
 
